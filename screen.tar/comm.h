
//constant definition
#define URL "http://www.cc.puv.fi/~gc/php/puttysize.php"

//function declaration

void sendpost(char *, char *);


